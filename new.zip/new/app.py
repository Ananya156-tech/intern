# from flask import Flask, render_template, request
# import pickle
# import re
# import string
# import os

# app = Flask(__name__)

# MODEL_PATH = "sentiment_model.pkl"

# if not os.path.exists(MODEL_PATH):
#     raise FileNotFoundError("sentiment_model.pkl not found. Please run train_model.py first.")

# with open(MODEL_PATH, "rb") as f:
#     model = pickle.load(f)

# def clean_text(text):
#     text = str(text).lower()
#     text = re.sub(r"http\S+|www\S+|https\S+", "", text)
#     text = re.sub(r"\d+", "", text)
#     text = text.translate(str.maketrans("", "", string.punctuation))
#     text = re.sub(r"\s+", " ", text).strip()
#     return text

# @app.route("/")
# def home():
#     return render_template("index.html")

# @app.route("/predict", methods=["POST"])
# def predict():
#     try:
#         user_text = request.form["text"]

#         if not user_text.strip():
#             return render_template(
#                 "index.html",
#                 prediction_text="Please enter some text."
#             )

#         cleaned_text = clean_text(user_text)

#         prediction = model.predict([cleaned_text])[0]
#         probability = model.predict_proba([cleaned_text])[0]

#         sentiment = "Positive" if prediction == 1 else "Negative"

#         return render_template(
#             "index.html",
#             prediction_text=sentiment,
#             user_input=user_text,
#             negative_confidence=round(float(probability[0]), 4),
#             positive_confidence=round(float(probability[1]), 4)
#         )

#     except Exception as e:
#         return render_template(
#             "index.html",
#             prediction_text=f"Error: {str(e)}"
#         )

# if __name__ == "__main__":
#     app.run(debug=True)

from flask import Flask, render_template, request
import pickle
import re
import string

app = Flask(__name__)

with open("sentiment_model.pkl", "rb") as f:
    model = pickle.load(f)

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+|https\S+", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    user_text = request.form.get("text", "")

    if not user_text.strip():
        return render_template("index.html", prediction_text="Please enter some text.")

    cleaned_text = clean_text(user_text)
    prediction = model.predict([cleaned_text])[0]

    sentiment = "Positive" if prediction == 1 else "Negative"

    return render_template("index.html", prediction_text=sentiment, user_input=user_text)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=False)